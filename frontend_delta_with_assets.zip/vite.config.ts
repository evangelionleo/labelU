import { resolve } from 'path';

import { defineConfig } from 'vite';
import { viteStaticCopy } from 'vite-plugin-static-copy';
import react from '@vitejs/plugin-react';
// import { viteMockServe } from 'vite-plugin-mock';
import svgr from 'vite-plugin-svgr';
import tsMonoAlias from 'vite-plugin-ts-mono-alias';
import { ViteEjsPlugin } from 'vite-plugin-ejs';

const isOnline = !!process.env.VITE_IS_ONLINE;
console.log('isOnline', isOnline);

// https://vitejs.dev/config/
export default defineConfig({
  base: '/',
  publicDir: resolve(__dirname, 'public'),
  envDir: resolve(__dirname, 'env'),
  server: {
    host: '0.0.0.0',
    allowedHosts: [
      '72eaff08.r11.cpolar.top',
      'localhost',
      '127.0.0.1',
      '0.0.0.0'
    ],
    proxy: {
      '/api/sam2': {
        target: 'http://127.0.0.1:5000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/sam2/, '/api'),
      },
      '/api/auto': {
        target: 'http://127.0.0.1:5001',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api\/auto/, '/api'),
      },
      '/api': {
        target: 'http://127.0.0.1:8000',
        changeOrigin: true,
      },
      '/ws': {
        target: 'ws://127.0.0.1:8000',
        ws: true,
        changeOrigin: true,
      }
    },
  },

  optimizeDeps: {
    include: ['react/jsx-runtime'],
  },

  plugins: [
    react(),
    svgr(),
    ViteEjsPlugin(),
    viteStaticCopy({
      targets: [
        { src: resolve(__dirname, '../scripts/pdf.min.js'), dest: 'scripts' },
        { src: resolve(__dirname, '../scripts/pdf.worker.min.js'), dest: 'scripts' },
        { src: resolve(__dirname, '../scripts/analyze-wiz.umd.js'), dest: 'scripts' },
        { src: resolve(__dirname, '../scripts/iconfont.js'), dest: 'scripts' },
      ],
    }),
    !process.env.DIST && process.env.NODE_ENV !== 'production' && tsMonoAlias(),
  ].filter(Boolean),
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src/'),
    },
  },
  build: {
    target: 'es2015',
    terserOptions: {
      compress: {
        drop_console: false,
        drop_debugger: true,
      },
    },
  },
});
