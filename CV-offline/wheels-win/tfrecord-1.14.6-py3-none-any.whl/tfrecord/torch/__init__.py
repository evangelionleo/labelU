from tfrecord.torch import dataset
from tfrecord.torch.dataset import MultiTFRecordDataset, TFRecordDataset
